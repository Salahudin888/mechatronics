#include <LiquidCrystal.h>

// Initialize the LCD (RS, E, D4, D5, D6, D7)
LiquidCrystal lcd(12, 11, 5, 4, 3, 2);

// Define pin numbers
const int redLEDPin = 9;       // Digital pin for red LED
const int yellowLEDPin = 10;    // Digital pin for yellow LED
const int greenLEDPin = 8;      // Digital pin for green LED

void setup() {
    // Initialize the serial monitor for debugging
    Serial.begin(9600);
    
    // Initialize the LCD
    lcd.begin(16, 2);
    
    // Set LED pins as output
    pinMode(redLEDPin, OUTPUT);
    pinMode(yellowLEDPin, OUTPUT);
    pinMode(greenLEDPin, OUTPUT);
}

void loop() {
    // Green Light
    digitalWrite(greenLEDPin, HIGH);
    lcd.clear();
    lcd.print("Green Light");
    Serial.println("Green Light");
    delay(10000); // Stay on for 10 seconds
    digitalWrite(greenLEDPin, LOW);

    // Yellow Light
    digitalWrite(yellowLEDPin, HIGH);
    lcd.clear();
    lcd.print("Yellow Light");
    Serial.println("Yellow Light");
    delay(5000); // Stay on for 5 seconds
    digitalWrite(yellowLEDPin, LOW);

    // Red Light
    digitalWrite(redLEDPin, HIGH);
    lcd.clear();
    lcd.print("Red Light");
    Serial.println("Red Light");
    delay(10000); // Stay on for 10 seconds
    digitalWrite(redLEDPin, LOW);
}
