//UltraSonic Pins (3 ultra sonic sensors)

//Front sensor
#define trig_Front 25 
#define echo_Front 24

//Right sensors
#define trig_Right1 9 
#define echo_Right1 6 

//Back sensor
#define trig_Back 29
#define echo_Back 28

//LED definition
int led_YELLOW=3;
int led_GREEN=18;
int led_RED=2;

//Motors Speed 
#define S 125

//Motor A
#define enA 9
#define in11 8
#define in12 7

//Motor B
#define enB 3
#define in21 5
#define in22 4

//Move Functions Prototype
void Stop();
void MoveForward();
void MoveLeft();
void MoveBack();
void MoveRight();

//ultra Sonic Function prototype
void Check();
int UFun(int triger,int echo);

//Parking function prototypes
void Parallel_Park();
void Perpendicular_Park();

//Variable definition
long duration_1;

void setup() 
      {
    //ultrasonic pins
    pinMode(trig_Back,OUTPUT);
    pinMode(echo_Back,INPUT);
    pinMode(trig_Right1,OUTPUT);
    pinMode(echo_Right1,INPUT);
    pinMode(trig_Front,OUTPUT);
    pinMode(echo_Front,INPUT);
    pinMode(led_GREEN, OUTPUT);
    pinMode(led_YELLOW, OUTPUT);
    pinMode(led_RED, OUTPUT);
  
    //Set all the motor control pins to outputs
    pinMode(enA, OUTPUT);
    pinMode(enB, OUTPUT);
    pinMode(in11, OUTPUT);
    pinMode(in12, OUTPUT);
    pinMode(in21, OUTPUT);
    pinMode(in22, OUTPUT);
    Serial.begin(9600);
}



void loop() 
      {
   delay(1000);
   MoveForward();
   delay(1000);

   Check();
       }


//Checking available parking space and detecting type of parking
void Check()
        {
        while(1)
           {
          if (UFun(trig_Front, echo_Front)<20)
              Stop();
          else
              MoveForward(); 
           
          long start=micros();
          while (UFun(trig_Right1,echo_Right1)>66)           
               {
             if (UFun(trig_Front, echo_Front)<20)
                Stop();
             else
                MoveForward(); 
               }
               
           duration_1= micros()-start;
       
           if ((duration_1/1000)>1000)
              {  
            Serial.print("duration_1=");
            Serial.println(duration_1/1000);
         
           if ((duration_1/1000)>1000 && (duration_1/1000)<2500)
               {
              Perpendicular_Park();
               }

            if ((duration_1/1000)>2500 && (duration_1/1000)<5200)
               {
              Parallel_Park();
               }
              
              }                 
             }              
            }


//Parallel Parking algorithm
void Parallel_Park()   
        {      
     digitalWrite(led_YELLOW,HIGH);
     delay(1000);
     Stop();
     delay(500);
     MoveBack();
     delay(1000);
     Stop();
     delay(500);
     MoveLeft();
     delay(2000);
      
     while(UFun(trig_Back,echo_Back)>15)
        {
       MoveBack();
        }
       Stop();
       delay(1000);
       MoveRight();
       delay(2000);
       Stop();
       digitalWrite(led_YELLOW,LOW);
       digitalWrite(led_GREEN,HIGH);
       exit(0);
        }

//Perpendicular parking algorthim
void Perpendicular_Park()
        {
        digitalWrite(led_RED,HIGH);
        delay(500);
        Stop();
        digitalWrite(led_RED,HIGH);
        delay(500);
        MoveBack();
        delay(2000);
        Stop();
        delay(500);
        MoveRight();
        delay(1000);
        Stop();
        delay(500);
        while(UFun(trig_Front, echo_Front)>15)
          {
          MoveForward();
          }
        Stop();
        digitalWrite(led_RED,LOW);
        digitalWrite(led_GREEN,HIGH);
        exit(0);
         }


//Ultrasoic sensor algorthim
int UFun(int triger , int echo)            
   {
   long duration_2;
   int distance;
        digitalWrite(triger,LOW);
        delayMicroseconds(2);
        digitalWrite(triger, HIGH);
        delayMicroseconds(10);
        digitalWrite(triger,LOW);
    
        duration_2 = pulseIn(echo,HIGH);
        distance = duration_2/2/29.1 ; // 331.5 m/s ===> 0 C.....331.5 +0.6*temp....343.5*100/1000000=.03435cm/us
        
        if(triger==25)
          {
          Serial.print("front=");
          Serial.print(distance);
          Serial.println("cm");
          }
        else if(triger==9)
          {
          Serial.print("Right#1=");
          Serial.print(distance);
          Serial.println("cm");
          }
        else if(triger==29)
          {
          Serial.print("Back=");
          Serial.print(distance);
          Serial.println("cm");
          }
   return distance; 
  }




//Function to move the robot back
void MoveBack()
      {
        //Turn on motor A
        digitalWrite(in11, LOW);
        digitalWrite(in12, HIGH);
      
        //Set speed to 200 out of possible range 0~255
        //analogWrite(enA, S);
      
        //Turn on motor B
        digitalWrite(in21, LOW);
        digitalWrite(in22, HIGH);
      
        //Set speed to 200 out of possible range 0~255
        //analogWrite(enB, S);
       }



//Function to move the robot left
void MoveLeft()
      {
      //Turn on motor A
      digitalWrite(in11, HIGH);
      digitalWrite(in12, LOW);

      //Set speed to 200 out of possible range 0~255
      //analogWrite(enA, S);

      //Turn on motor 
      digitalWrite(in21, LOW);
      digitalWrite(in22, HIGH);

      //Set speed to 200 out of possible range 0~255
      //analogWrite(enB, S);
      }


//Function to move the robot right
void MoveRight()
    {
 
     //Turn on motor A
     digitalWrite(in11, LOW);
     digitalWrite(in12, HIGH);

     //Set speed to 200 out of possible range 0~255
//     analogWrite(enA, S);

     //Turn on motor B
     digitalWrite(in21, HIGH);
     digitalWrite(in22, LOW);

     //Set speed to 200 out of possible range 0~255
//     analogWrite(enB, S);
     }



//Function to move the robot forward
void MoveForward() 
    {
   
       //Turn on motor A
       digitalWrite(in11, HIGH);
       digitalWrite(in12, LOW);

       //Set speed to 200 out of possible range 0~255
//        analogWrite(enA, S);

       //Turn on motor B
       digitalWrite(in21, HIGH);
       digitalWrite(in22, LOW);

       //Set speed to 200 out of possible range 0~255
//       analogWrite(enB, S);
     }



//Function to stop the robot 
void Stop()
  {
    
       //Now turn off all the motors
       digitalWrite(in11, LOW);
       digitalWrite(in12, LOW);  
       digitalWrite(in21, LOW);
       digitalWrite(in22, LOW);
  
  }
