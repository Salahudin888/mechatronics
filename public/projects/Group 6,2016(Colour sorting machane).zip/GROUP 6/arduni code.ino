 #include <LiquidCrystal.h>
#include <Servo.h>

// LCD pin configuration
LiquidCrystal lcd(12, 11, 5, 4, 3, 2);

// Servo motors
Servo servo1;  // First servo motor (rotates continuously between 0, 70, and 90 degrees)
Servo servo2;  // Second servo motor (rotates based on the LED)

// LED pins
const int redLedPin = 9;
const int yellowLedPin = 10;
const int greenLedPin = 7;
const int rgbRedPin = A2;
const int rgbGreenPin = A3;
const int rgbBluePin = A4;

// Photodiode pin
const int photoPin = A1;

// Function to light RGB LED in a random color (excluding red, green, and yellow)
void lightRGBLed() {
  int randomColor = random(1, 5);
  switch (randomColor) {
    case 1: // Blue
      analogWrite(rgbRedPin, 0);
      analogWrite(rgbGreenPin, 0);
      analogWrite(rgbBluePin, 255);
      break;
    case 2: // Purple
      analogWrite(rgbRedPin, 128);
      analogWrite(rgbGreenPin, 0);
      analogWrite(rgbBluePin, 128);
      break;
    case 3: // Cyan
      analogWrite(rgbRedPin, 0);
      analogWrite(rgbGreenPin, 255);
      analogWrite(rgbBluePin, 255);
      break;
    case 4: // White
      analogWrite(rgbRedPin, 255);
      analogWrite(rgbGreenPin, 255);
      analogWrite(rgbBluePin, 255);
      break;
  }
}

void setup() {
  // LED pin setup
  pinMode(redLedPin, OUTPUT);
  pinMode(yellowLedPin, OUTPUT);
  pinMode(greenLedPin, OUTPUT);
  pinMode(rgbRedPin, OUTPUT);
  pinMode(rgbGreenPin, OUTPUT);
  pinMode(rgbBluePin, OUTPUT);

  // Servo pin setup
  servo1.attach(6);
  servo2.attach(8);

  // Initialize LCD
  lcd.begin(16, 2);
  lcd.clear();

  // Initialize servo1 at 0 degrees
  servo1.write(0);

  // Set random seed for RGB LED
  randomSeed(analogRead(0));
}

void loop() {
  // Rotate servo1 to 70 degrees, stop briefly, then rotate to 90 degrees, and finally return to 0 degrees
  servo1.write(70);
  delay(300);  // Stop briefly at 70 degrees
  servo1.write(90);
  delay(300);  // Stop at 90 degrees (where LEDs light up)

  // Light LEDs and control servo2 only when servo1 is at 90 degrees
  int ledToLight = random(1, 5);  // Randomly select which LED to light (1 = red, 2 = yellow, 3 = green, 4 = RGB)

  // Turn off all LEDs before lighting the next one
  digitalWrite(redLedPin, LOW);
  digitalWrite(yellowLedPin, LOW);
  digitalWrite(greenLedPin, LOW);
  analogWrite(rgbRedPin, 0);
  analogWrite(rgbGreenPin, 0);
  analogWrite(rgbBluePin, 0);

  // Handle random LED lighting and actions
  switch (ledToLight) {
    case 1: // Red LED
      digitalWrite(redLedPin, HIGH);
      lcd.clear();
      lcd.print("LED: Red");  // Display "Red" on LCD
      servo2.write(30);  // Rotate servo2 to 30 degrees
      break;

    case 2: // Yellow LED
      digitalWrite(yellowLedPin, HIGH);
      lcd.clear();
      lcd.print("LED: Yellow");  // Display "Yellow" on LCD
      servo2.write(60);  // Rotate servo2 to 60 degrees
      break;

    case 3: // Green LED
      digitalWrite(greenLedPin, HIGH);
      lcd.clear();
      lcd.print("LED: Green");  // Display "Green" on LCD
      servo2.write(90);  // Rotate servo2 to 90 degrees
      break;

    case 4: // RGB LED (random color)
      lightRGBLed();
      lcd.clear();
      lcd.print("LED: Scrap");  // Display "Scrap" on LCD for random RGB colors
      servo2.write(120);  // Rotate servo2 to 120 degrees
      break;
  }

  // Simulate photodiode detection (this part can be customized if needed)
  int photoValue = analogRead(photoPin);

  delay(300);  // LED stays on for this time
  servo1.write(0);  // Return servo1 to 0 degrees
  delay(300);  // Stop briefly before repeating the cycle
}
