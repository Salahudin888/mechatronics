// Assigning analog pin A3 to variable 'sensor' for temperature simulation
const int sensor = A3;  // Note: changed to A3 instead of A03 for proper pin assignment

// Assign Names to Pins for Motor Control
const int Speed_Pin  = A0;  // Speed Control Pin
const int Clockwise_Pin  = A1;  // Clockwise Control Button Pin
const int AClockwise_Pin = A2;  // Anti-Clockwise Control Button Pin

// Motor Driver Pins
const int IN1 = 13;
const int IN2 = 12;
const int ENA = 11;  // PWM pin for motor speed control

void setup() 
{
  // Serial Monitor for Temperature Sensor
  Serial.begin(9600);
  Serial.println("Temperature Sensor and Motor Control Simulation");
  Serial.println();
  delay(1000);
  pinMode(8,OUTPUT); //Set the Heater/Relay Pin as OUTPUT
  
  // Motor Control Pin Setup
  pinMode(Clockwise_Pin,  INPUT_PULLUP);  // Set the pin as INPUT_PULLUP 
  pinMode(AClockwise_Pin, INPUT_PULLUP);  // Set the pin as INPUT_PULLUP 
  pinMode(Speed_Pin, INPUT);  // Set the pin as INPUT
  
  // Motor
  pinMode(IN1, OUTPUT);  // Set the pin as OUTPUT 
  pinMode(IN2, OUTPUT);  // Set the pin as OUTPUT 
  pinMode(ENA, OUTPUT);  // PWM Pin

  // Heater/Relay Pin Setup
  pinMode(8, OUTPUT);  // Set the Heater/Relay Pin as OUTPUT
}

void loop() 
{
  float Sensor_Data = analogRead(A3);  // Read the input on Analog pin A3
  int Temp = (Sensor_Data * 500) / 1023; // Storing value in Degree Celsius
  
  if (Temp < 20) // If Temperature is Less Than 20°C
  {
    digitalWrite(8, HIGH);  // Turn ON the Heater
  }
  else
  {
    digitalWrite(8, LOW);  // Turn OFF the Heater
  }

  // Motor Control Simulation
  int Clockwise = digitalRead(Clockwise_Pin);  // Read the input from Clockwise control button
  int AClockwise = digitalRead(AClockwise_Pin);  // Read the input from Anti-clockwise control button
  int Speed_Value = analogRead(Speed_Pin);  // Read the input from Speed control potentiometer
  
  int Motor_Speed = map(Speed_Value, 0, 1023, 0, 255);  // Map speed from 0-1023 to 0-255 (PWM range)
  analogWrite(ENA, Motor_Speed);  // PWM Signal to control motor speed (0-255)

  if (Clockwise == LOW) 
  {
    // Start Motor in Clockwise Direction
    digitalWrite(IN1, HIGH);
    digitalWrite(IN2, LOW);
  } 
  else if (AClockwise == LOW) 
  {
    // Start Motor in Anti-Clockwise Direction
    digitalWrite(IN1, LOW);
    digitalWrite(IN2, HIGH);
  } 
  else 
  {
    // Stop the Motor
    digitalWrite(IN1, LOW);
    digitalWrite(IN2, LOW);
  }
  
  delay(500);  // Added a 500ms delay to reduce CPU load between motor control checks
}

