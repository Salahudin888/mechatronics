// Define pin connections
int soilMoisturePin = A1;     // The analog pin for the soil moisture sensor
int potPin = A2;              // The analog pin for the potentiometer (POT-HG)
int motorPin = 13;            // Pin for controlling motor through relay
int soundSensorPin = 2;       // Pin for sound sensor input
int motorState = LOW;         // Motor state (initially off)

void setup() {
  pinMode(soilMoisturePin, INPUT);    // Soil moisture sensor pin
  pinMode(potPin, INPUT);             // Potentiometer pin
  pinMode(motorPin, OUTPUT);          // Motor control pin
  pinMode(soundSensorPin, INPUT);     // Sound sensor pin
  
  // Start serial communication (for Bluetooth)
  Serial.begin(9600); 
  
  // Ensure motor is off at the start
  digitalWrite(motorPin, LOW);
}

void loop() {
  // Call the soil moisture and potentiometer function
  handleSoilMoistureAndPot();
  
  // Call the sound sensor and motor control function
  handleSoundSensorAndMotor();
  
  delay(500);  // Delay to stabilize the loop
}

// Function to handle soil moisture sensor, potentiometer, and Bluetooth communication
void handleSoilMoistureAndPot() {
  // Read the soil moisture sensor value
  int soilMoistureValue = analogRead(soilMoisturePin);

  // Read the potentiometer value
  int potValue = analogRead(potPin); 
  
  // Map the potentiometer value (0-1023) to a percentage (0-100)
  int potPercentage = map(potValue, 0, 1023, 0, 100);
  
  // Print the soil moisture value and potentiometer percentage (for debugging)
  Serial.print("Soil Moisture: ");
  Serial.println(soilMoistureValue);
  Serial.print("Potentiometer Value (Percentage): ");
  Serial.println(potPercentage);

  // Check if the potentiometer percentage is above or below 56%
  if (potPercentage > 56) {
    // If above 56%, send a message over Bluetooth
    Serial.println("the bed is not wet");
  } else {
    // If below 56%, send a message to indicate dry soil
    Serial.println("the bed is wet it needs replacement");
  }
}

// Function to handle sound sensor and motor control
void handleSoundSensorAndMotor() {
  // Read the sound sensor value
  int soundDetected = digitalRead(soundSensorPin);
  
  // If sound is detected, swing the cradle by turning the motor on
  if (soundDetected == HIGH) {
    motorState = HIGH;          // Turn motor on
    digitalWrite(motorPin, motorState); // Set motor pin HIGH
    delay(2500);                // Keep motor on for 5 seconds
    motorState = LOW;           // Turn motor off
    digitalWrite(motorPin, motorState); // Set motor pin LOW
  } else {
    // If no sound is detected, ensure motor is off
    digitalWrite(motorPin, LOW);
  }
}